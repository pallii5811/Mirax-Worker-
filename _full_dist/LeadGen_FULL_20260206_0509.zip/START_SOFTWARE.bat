@echo off
setlocal
title LeadGen Launcher
cd /d "%~dp0"

echo ==========================================
echo AVVIO FORZATO SISTEMA
echo ==========================================

echo.
echo [1/3] Configurazione Motore...

echo Installo dipendenze Python...
cd backend
call pip install -r requirements.txt --quiet
echo Avvio Backend in nuova finestra...
start "MOTORE BACKEND" cmd /k "python -m uvicorn main:app --port 8000"
cd ..

echo.
echo [2/3] Attendo avvio del server (5 secondi)...
timeout /t 5 >nul

echo.
echo [3/3] Avvio Interfaccia...

start http://localhost:3000

cd frontend
call npm install --quiet
start "INTERFACCIA" cmd /k "npm run dev"
cd ..

pause
