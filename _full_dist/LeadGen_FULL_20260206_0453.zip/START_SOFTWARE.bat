@echo off
setlocal
title LeadGen Launcher
cd /d "%~dp0"

echo ==========================================
echo AVVIO FORZATO SISTEMA
echo ==========================================

echo.
echo [1/3] Configurazione Motore...

if exist "backend\main.py" (
  echo Trovato backend in cartella 'backend'.
  pip install -r backend\requirements.txt --quiet
  echo Avvio Backend in nuova finestra...
  start "MOTORE BACKEND" cmd /k "python -m uvicorn backend.main:app --port 8000"
) else (
  echo Backend non trovato in 'backend'.
  echo Avvio Backend in nuova finestra...
  start "MOTORE BACKEND" cmd /k "python -m uvicorn backend.main:app --port 8000"
)

echo.
echo [2/3] Attendo avvio del server (5 secondi)...
timeout /t 5 >nul

echo.
echo [3/3] Avvio Interfaccia...

start http://localhost:3000

call npm --prefix frontend install --quiet
start "INTERFACCIA" cmd /k "npm --prefix frontend run dev"

pause
