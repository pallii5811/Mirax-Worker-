export const BACKEND_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000";

export type JobState = "queued" | "running" | "done" | "error";

export type AuditSignals = {
  has_facebook_pixel: boolean;
  has_tiktok_pixel: boolean;
  has_gtm: boolean;
  has_ssl: boolean;
  is_mobile_responsive: boolean;
};

export type BusinessResult = {
  result_index: number;
  business_name: string;
  address?: string | null;
  phone?: string | null;
  email?: string | null;
  website?: string | null;
  website_status: "HAS_WEBSITE" | "MISSING_WEBSITE";
  website_http_status?: number | null;
  website_error?: string | null;
  website_has_html?: boolean;
  website_error_line?: number | null;
  website_error_hint?: string | null;
  audit: AuditSignals;
};

export type JobStatus = {
  id: string;
  state: JobState;
  progress: number;
  message: string;
  started_at: number;
  finished_at?: number | null;
  error?: string | null;
};

export async function startJob(category: string, city: string): Promise<JobStatus> {
  const r = await fetch(`${BACKEND_URL}/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ category, city }),
  });
  if (!r.ok) throw new Error("Failed to start job");
  return (await r.json()) as JobStatus;
}

export async function fetchResults(jobId: string): Promise<BusinessResult[]> {
  const r = await fetch(`${BACKEND_URL}/jobs/${jobId}/results`);
  if (!r.ok) throw new Error("Failed to fetch results");
  return (await r.json()) as BusinessResult[];
}

export async function fetchJob(jobId: string): Promise<JobStatus> {
  const r = await fetch(`${BACKEND_URL}/jobs/${jobId}`);
  if (!r.ok) throw new Error("Failed to fetch job");
  return (await r.json()) as JobStatus;
}
