"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDown,
  ArrowUp,
  Copy,
  ExternalLink,
  FileDown,
  FileText,
  MessageCircle,
  Phone,
  Search,
  Rocket,
} from "lucide-react";
import * as React from "react";
import { jsPDF } from "jspdf";

import type { BusinessResult, JobStatus } from "@/lib/api";
import { BACKEND_URL, fetchJob, fetchResults, startJob } from "@/lib/api";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

function useDebouncedValue<T>(value: T, delayMs: number): T {
  const [debounced, setDebounced] = React.useState(value);
  React.useEffect(() => {
    const t = window.setTimeout(() => setDebounced(value), delayMs);
    return () => window.clearTimeout(t);
  }, [value, delayMs]);
  return debounced;
}

function buildPitchEmail(row: BusinessResult) {
  const name = row.business_name;

  if (row.website_status === "MISSING_WEBSITE") {
    return {
      subject: `Proposta rapida: aumentiamo i clienti di ${name} (presenza online)`,
      body:
        `Ciao ${name},\n\n` +
        `ho trovato la tua attività su Google Maps ma non risulta un sito web ufficiale. Oggi questo significa perdere richieste e prenotazioni da chi cerca online e confronta alternative.\n\n` +
        `In 7-10 giorni possiamo realizzare una landing/sito veloce, ottimizzato per mobile e per la conversione, con tracking completo e contatti immediati (WhatsApp/call).\n\n` +
        `Se ti va, ti mando una bozza gratuita della struttura (sezioni + call-to-action) e una stima dei tempi.\n\n` +
        `Ti interessa che te la prepari?\n\n` +
        `—`,
    };
  }

  if (row.website_status === "HAS_WEBSITE" && !row.audit.has_facebook_pixel) {
    return {
      subject: `${name}: manca il Pixel FB (stai perdendo retargeting)`,
      body:
        `Ciao ${name},\n\n` +
        `ho fatto un audit rapido del tuo sito e non ho rilevato il Facebook Pixel attivo. Questo di solito significa che eventuali campagne ads non possono fare retargeting in modo efficace (chi visita il sito poi “sparisce”).\n\n` +
        `In pratica: stai pagando traffico, ma perdi la parte più profittevole (recupero visitatori, lookalike, ottimizzazione eventi).\n\n` +
        `Posso: installare Pixel + eventi (lead/chiamata/whatsapp), verificare conversioni e impostare una struttura retargeting base.\n\n` +
        `Ti va se ti mando un piano di intervento in 3 punti + costo fisso?\n\n` +
        `—`,
    };
  }

  return {
    subject: `Complimenti ${name}: audit positivo — proposta di crescita`,
    body:
      `Ciao ${name},\n\n` +
      `complimenti: dal controllo che ho fatto risulta una buona base (sito presente e tracking ok).\n\n` +
      `Se vuoi spingere ancora, posso proporti una gestione avanzata: contenuti + social + campagne con ottimizzazione e reporting mensile, per aumentare richieste e prenotazioni.\n\n` +
      `Ti va una call di 10 minuti per capire obiettivi e target?\n\n` +
      `—`,
  };
}

function buildAuditIssues(row: BusinessResult): string[] {
  const issues: string[] = [];
  if (row.website_status === "MISSING_WEBSITE") {
    issues.push("Sito Web: ASSENTE");
    return issues;
  }

  if (!row.audit.has_facebook_pixel) issues.push("Facebook Pixel: MANCANTE");
  if (!row.audit.has_gtm) issues.push("Google Tag Manager: MANCANTE");
  if (!row.audit.has_ssl) issues.push("SSL (HTTPS): NON ATTIVO");
  if (!row.audit.is_mobile_responsive) issues.push("Mobile Responsive: NON RILEVATO");
  return issues;
}

function downloadPdfReport(row: BusinessResult) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const marginX = 48;
  let y = 64;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text(`Digital Audit Report per ${row.business_name}`, marginX, y);
  y += 18;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(120);
  doc.text(`Generato: ${new Date().toLocaleString()}`, marginX, y);
  y += 28;

  const issues = buildAuditIssues(row);
  doc.setTextColor(20);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("Problemi rilevati", marginX, y);
  y += 18;

  if (issues.length === 0) {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.setTextColor(30);
    doc.text("Nessun problema critico rilevato.", marginX, y);
    y += 18;
  } else {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(200, 40, 60);
    for (const issue of issues) {
      doc.text(`• ${issue}`, marginX, y);
      y += 18;
      if (y > 760) {
        doc.addPage();
        y = 64;
      }
    }
  }

  doc.setFont("helvetica", "normal");
  doc.setTextColor(120);
  doc.setFontSize(10);
  doc.text("Generato da [Nome Tua Agenzia]", marginX, 820);

  const filename = `audit_${row.business_name}`
    .replace(/\s+/g, "_")
    .replace(/[^a-zA-Z0-9_\-]/g, "")
    .slice(0, 60);
  doc.save(`${filename}.pdf`);
}

function cleanPhoneForWhatsApp(phone: string): string {
  let p = phone.trim();
  p = p.replace(/^\+/, "");
  p = p.replace(/^00/, "");
  p = p.replace(/[^0-9]/g, "");
  if (p.startsWith("39") && p.length > 10) {
    p = p.slice(2);
  }
  return p;
}

function buildSocialSearchUrl(businessName: string, city: string): string {
  const q = `site:instagram.com OR site:facebook.com "${businessName} ${city}"`;
  return `https://www.google.com/search?q=${encodeURIComponent(q)}`;
}

function MarketingBadges({ row }: { row: BusinessResult }) {
  const missingFb = row.website_status === "HAS_WEBSITE" && !row.audit.has_facebook_pixel;
  const missingGtm = row.website_status === "HAS_WEBSITE" && !row.audit.has_gtm;

  return (
    <div className="flex flex-wrap items-center gap-2">
      {missingFb ? (
        <Badge variant="danger">MISSING FB PIXEL</Badge>
      ) : (
        <Badge variant="success">FB PIXEL OK</Badge>
      )}
      {!row.audit.has_tiktok_pixel ? (
        <Badge variant="warning">No TikTok</Badge>
      ) : (
        <Badge variant="success">TikTok OK</Badge>
      )}
      {missingGtm ? (
        <Badge variant="warning">Missing GTM</Badge>
      ) : (
        <Badge variant="success">GTM OK</Badge>
      )}
    </div>
  );
}

function WebsiteCodeError({ row }: { row: BusinessResult }) {
  const status = row.website_http_status ?? null;
  const err = String(row.website_error ?? "").trim();

  const show = (typeof status === "number" && status >= 400) || err.length > 0;
  if (!show) return null;

  const label =
    typeof status === "number" && status >= 400
      ? `HTTP ${status}`
      : err || "Errore sito";

  return (
    <div className="mb-2 rounded-md border border-red-500/40 bg-red-500/10 px-2 py-1 text-[11px] font-medium text-red-400">
      ERRORE CODICE SITO: {label}
    </div>
  );
}

function WebsiteCodeErrorCell({ row, jobId }: { row: BusinessResult; jobId: string }) {
  const status = row.website_http_status ?? null;
  const err = String(row.website_error ?? "").trim();

  const show = (typeof status === "number" && status >= 400) || err.length > 0;
  if (!show) return <span className="text-xs text-muted-foreground">—</span>;

  const label =
    typeof status === "number" && status >= 400
      ? `HTTP ${status}`
      : err || "Errore";

  const line = row.website_error_line ?? null;
  const url = `${BACKEND_URL}/jobs/${jobId}/sites/${row.result_index}/html${
    line ? `?line=${encodeURIComponent(String(line))}` : ""
  }`;
  const hasHtml = Boolean(row.website_has_html);

  return (
    <div className="flex flex-col gap-1">
      <div className="rounded-md border border-red-500/40 bg-red-500/10 px-2 py-1 text-[11px] font-semibold text-red-400">
        {label}
      </div>
      {hasHtml ? (
        <a
          className="text-[11px] font-medium text-red-300 underline underline-offset-2"
          href={url}
          target="_blank"
          rel="noreferrer"
        >
          Apri HTML
        </a>
      ) : (
        <span className="text-[11px] text-muted-foreground">HTML non disponibile</span>
      )}
    </div>
  );
}

function ResultsSkeleton() {
  return (
    <div className="overflow-hidden rounded-lg border border-border">
      <div className="bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
        Loading results...
      </div>
      <div className="divide-y divide-border">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="grid grid-cols-12 gap-4 px-4 py-4">
            <div className="col-span-4 space-y-2">
              <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
              <div className="h-3 w-full animate-pulse rounded bg-muted/70" />
            </div>
            <div className="col-span-3 space-y-2">
              <div className="h-3 w-5/6 animate-pulse rounded bg-muted" />
              <div className="h-3 w-3/6 animate-pulse rounded bg-muted/70" />
            </div>
            <div className="col-span-3 space-y-2">
              <div className="h-6 w-4/6 animate-pulse rounded bg-muted" />
              <div className="h-6 w-3/6 animate-pulse rounded bg-muted/70" />
            </div>
            <div className="col-span-2 space-y-2">
              <div className="h-6 w-full animate-pulse rounded bg-muted" />
              <div className="h-6 w-5/6 animate-pulse rounded bg-muted/70" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WebsiteStatusBadge({ row }: { row: BusinessResult }) {
  if (row.website_status === "HAS_WEBSITE") {
    return (
      <div className="flex items-center gap-2">
        <Badge variant="success">WEBSITE OK</Badge>
        <Badge variant={row.audit.has_ssl ? "success" : "warning"}>
          {row.audit.has_ssl ? "SSL" : "NO SSL"}
        </Badge>
        <Badge variant={row.audit.is_mobile_responsive ? "success" : "warning"}>
          {row.audit.is_mobile_responsive ? "MOBILE" : "NOT MOBILE"}
        </Badge>
      </div>
    );
  }

  return <Badge variant="danger">NO WEBSITE</Badge>;
}

function ResultsTable({
  rows,
  city,
  jobId,
  onPitch,
  onPdf,
}: {
  rows: BusinessResult[];
  city: string;
  jobId: string;
  onPitch: (row: BusinessResult) => void;
  onPdf: (row: BusinessResult) => void;
}) {
  return (
    <div className="overflow-hidden rounded-lg border border-border">
      <table className="w-full text-sm">
        <thead className="bg-muted/40">
          <tr className="text-left">
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Business Name
            </th>
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Contacts
            </th>
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Website Status
            </th>
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Marketing Audit
            </th>
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Errori Sito
            </th>
            <th className="px-4 py-3 font-medium text-muted-foreground">
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => (
            <tr
              key={`${row.business_name}-${idx}`}
              className="border-t border-border hover:bg-muted/20"
            >
              <td className="px-4 py-4">
                <div className="font-semibold">{row.business_name}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {row.address ?? ""}
                </div>
              </td>
              <td className="px-4 py-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    {row.phone ? (
                      <>
                        <a
                          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground"
                          href={`tel:${row.phone}`}
                        >
                          <Phone className="h-4 w-4" />
                          <span className="text-xs">{row.phone}</span>
                        </a>

                        <a
                          className="inline-flex items-center text-muted-foreground hover:text-foreground"
                          href={`https://wa.me/${cleanPhoneForWhatsApp(row.phone)}`}
                          target="_blank"
                          rel="noreferrer"
                          title="WhatsApp"
                        >
                          <MessageCircle className="h-4 w-4" />
                        </a>

                        <button
                          type="button"
                          className="inline-flex items-center text-muted-foreground hover:text-foreground"
                          onClick={() =>
                            window.open(
                              buildSocialSearchUrl(row.business_name, city),
                              "_blank",
                              "noopener,noreferrer",
                            )
                          }
                          title="Find Social"
                        >
                          <Search className="h-4 w-4" />
                        </button>
                      </>
                    ) : (
                      <span className="text-xs text-muted-foreground">No phone</span>
                    )}

                    {row.website ? (
                      <a
                        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground"
                        href={row.website}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span className="text-xs">Website</span>
                      </a>
                    ) : null}
                  </div>

                  {row.email ? (
                    <div className="text-xs text-muted-foreground">{row.email}</div>
                  ) : null}
                </div>
              </td>
              <td className="px-4 py-4">
                <WebsiteStatusBadge row={row} />
              </td>
              <td className="px-4 py-4">
                <MarketingBadges row={row} />
              </td>
              <td className="px-4 py-4">
                <WebsiteCodeErrorCell row={row} jobId={jobId} />
              </td>
              <td className="px-4 py-4">
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => onPitch(row)}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Genera Pitch
                  </Button>

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onPdf(row)}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Download Report
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Dashboard() {
  const demoCity = (process.env.NEXT_PUBLIC_DEMO_CITY ?? "").trim();
  const demoCategories = React.useMemo(() => {
    const raw = (process.env.NEXT_PUBLIC_DEMO_CATEGORIES ?? "").trim();
    if (!raw) return [] as string[];
    return raw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  }, []);
  const isDemo = Boolean(demoCity) || demoCategories.length > 0;

  const presets = React.useMemo(
    () => [
      "Ristoranti",
      "Pizzerie",
      "Bar",
      "Hotel",
      "Dentisti",
      "Avvocati",
      "Commercialisti",
      "Palestre",
      "Parrucchieri",
      "Centri estetici",
      "Agenzie immobiliari",
      "Agenzie marketing",
      "Social media manager",
      "Sviluppatori siti web",
      "Carrozzerie",
      "Officine meccaniche",
      "Fotografi",
      "Studi medici",
      "Custom…",
    ],
    []
  );

  const italyCityIndex = React.useMemo(
    () => [
      "Agrigento",
      "Alessandria",
      "Ancona",
      "Aosta",
      "Arezzo",
      "Ascoli Piceno",
      "Asti",
      "Avellino",
      "Bari",
      "Barletta",
      "Belluno",
      "Benevento",
      "Bergamo",
      "Biella",
      "Bologna",
      "Bolzano",
      "Brescia",
      "Brindisi",
      "Cagliari",
      "Caltanissetta",
      "Campobasso",
      "Caserta",
      "Catania",
      "Catanzaro",
      "Chieti",
      "Como",
      "Cosenza",
      "Cremona",
      "Crotone",
      "Cuneo",
      "Enna",
      "Fermo",
      "Ferrara",
      "Firenze",
      "Foggia",
      "Forlì",
      "Frosinone",
      "Genova",
      "Gorizia",
      "Grosseto",
      "Imperia",
      "Isernia",
      "La Spezia",
      "L'Aquila",
      "Latina",
      "Lecce",
      "Lecco",
      "Livorno",
      "Lodi",
      "Lucca",
      "Macerata",
      "Mantova",
      "Massa",
      "Matera",
      "Messina",
      "Milano",
      "Modena",
      "Monza",
      "Napoli",
      "Novara",
      "Nuoro",
      "Oristano",
      "Padova",
      "Palermo",
      "Parma",
      "Pavia",
      "Perugia",
      "Pesaro",
      "Pescara",
      "Piacenza",
      "Pisa",
      "Pistoia",
      "Pordenone",
      "Potenza",
      "Prato",
      "Ragusa",
      "Ravenna",
      "Reggio Calabria",
      "Reggio Emilia",
      "Rieti",
      "Rimini",
      "Roma",
      "Rovigo",
      "Salerno",
      "Sassari",
      "Savona",
      "Siena",
      "Siracusa",
      "Sondrio",
      "Taranto",
      "Teramo",
      "Terni",
      "Torino",
      "Trapani",
      "Trento",
      "Treviso",
      "Trieste",
      "Udine",
      "Varese",
      "Venezia",
      "Verbano-Cusio-Ossola",
      "Vercelli",
      "Verona",
      "Vibo Valentia",
      "Vicenza",
      "Viterbo",
    ],
    [],
  );

  const categoryPresets = React.useMemo(() => {
    if (!demoCategories.length) return presets;
    const allowed = new Set(demoCategories);
    return presets.filter((p) => allowed.has(p));
  }, [demoCategories, presets]);

  const [categoryMode, setCategoryMode] = React.useState<"preset" | "custom">(
    "preset",
  );
  const [categoryPreset, setCategoryPreset] = React.useState(
    demoCategories[0] ?? "Ristoranti",
  );
  const [categoryCustom, setCategoryCustom] = React.useState("");

  const category =
    categoryMode === "custom" ? categoryCustom : categoryPreset;

  const cityPresets = React.useMemo(
    () => [
      "Milano",
      "Roma",
      "Torino",
      "Napoli",
      "Bologna",
      "Firenze",
      "Venezia",
      "Palermo",
      "Genova",
      "Verona",
      "Custom…",
    ],
    []
  );

  const cityPresetOptions = React.useMemo(() => {
    if (!demoCity) return cityPresets;
    return [demoCity];
  }, [demoCity, cityPresets]);

  const [cityMode, setCityMode] = React.useState<"preset" | "custom">("preset");
  const [cityPreset, setCityPreset] = React.useState(demoCity || "Milano");
  const [cityCustom, setCityCustom] = React.useState("");

  const city = cityMode === "custom" ? cityCustom : cityPreset;

  const debouncedCityQuery = useDebouncedValue(demoCity ? "" : city.trim(), 250);
  const [citySuggestions, setCitySuggestions] = React.useState<string[]>([]);
  const [citySuggestOpen, setCitySuggestOpen] = React.useState(false);

  const cityStaticOptions = React.useMemo(() => {
    const merged = [
      ...italyCityIndex,
      ...cityPresets.filter((c) => c !== "Custom…"),
    ];
    return Array.from(new Set(merged.map((s) => String(s).trim()).filter(Boolean)));
  }, [italyCityIndex, cityPresets]);

  const cityDropdownOptions = React.useMemo(() => {
    const merged = [...cityStaticOptions, ...citySuggestions];
    return Array.from(new Set(merged.map((s) => String(s).trim()).filter(Boolean)));
  }, [cityStaticOptions, citySuggestions]);

  const cityFilteredOptions = React.useMemo(() => {
    const q = (demoCity ? "" : city.trim()).toLowerCase();
    const list = !q
      ? cityDropdownOptions
      : cityDropdownOptions.filter((s) => s.toLowerCase().includes(q));
    return list.slice(0, 30);
  }, [demoCity, city, cityDropdownOptions]);

  React.useEffect(() => {
    const q = debouncedCityQuery;
    if (!q || q.length < 2) {
      setCitySuggestions([]);
      return;
    }

    const ac = new AbortController();
    (async () => {
      try {
        const url =
          "https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=it&addressdetails=1&limit=8&q=" +
          encodeURIComponent(q);
        const res = await fetch(url, {
          signal: ac.signal,
          headers: {
            "Accept": "application/json",
          },
        });
        if (!res.ok) {
          setCitySuggestions([]);
          return;
        }
        const data = (await res.json()) as Array<any>;
        const names = data
          .map((x) => {
            const a = x?.address;
            return (
              a?.city ||
              a?.town ||
              a?.village ||
              a?.hamlet ||
              a?.municipality ||
              x?.name ||
              ""
            );
          })
          .map((s) => String(s).trim())
          .filter(Boolean);
        const uniq = Array.from(new Set(names));
        setCitySuggestions(uniq);
      } catch (e) {
        if ((e as any)?.name === "AbortError") return;
        setCitySuggestions([]);
      }
    })();

    return () => ac.abort();
  }, [debouncedCityQuery]);

  React.useEffect(() => {
    if (!demoCategories.length) return;
    if (!demoCategories.includes(categoryPreset)) {
      setCategoryPreset(demoCategories[0]);
      setCategoryMode("preset");
      setCategoryCustom("");
    }
  }, [demoCategories, categoryPreset]);

  React.useEffect(() => {
    if (!demoCity) return;
    if (cityPreset !== demoCity) {
      setCityPreset(demoCity);
      setCityMode("preset");
      setCityCustom("");
    }
  }, [demoCity, cityPreset]);

  const [job, setJob] = React.useState<JobStatus | null>(null);
  const [progress, setProgress] = React.useState(0);
  const [message, setMessage] = React.useState("—");
  const [state, setState] = React.useState<string | null>(null);
  const [rows, setRows] = React.useState<BusinessResult[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [sortDir, setSortDir] = React.useState<"desc" | "asc">("desc");

  const [pitchOpen, setPitchOpen] = React.useState(false);
  const [pitchRow, setPitchRow] = React.useState<BusinessResult | null>(null);
  const [copied, setCopied] = React.useState(false);

  const sortedRows = React.useMemo(() => {
    const score = (r: BusinessResult) => {
      if (r.website_status === "HAS_WEBSITE" && !r.audit.has_facebook_pixel) return 1200;
      if (r.website_status === "MISSING_WEBSITE") return 1100;
      let s = 0;
      if (!r.audit.has_facebook_pixel) s += 200;
      if (!r.audit.has_gtm) s += 60;
      if (!r.audit.has_ssl) s += 30;
      if (!r.audit.is_mobile_responsive) s += 20;
      return s;
    };

    const dir = sortDir === "desc" ? -1 : 1;
    return [...rows].sort((a, b) => (score(a) - score(b)) * dir);
  }, [rows, sortDir]);

  async function onStart() {
    setLoading(true);
    setRows([]);
    setProgress(0);
    setMessage("Starting...");

    try {
      const j = await startJob(category, city);
      setJob(j);
      setState(j.state);

      let pollingTimer: number | null = null;
      const stopPolling = () => {
        if (pollingTimer) {
          window.clearInterval(pollingTimer);
          pollingTimer = null;
        }
      };

      const startPolling = () => {
        if (pollingTimer) return;
        pollingTimer = window.setInterval(async () => {
          try {
            const s = await fetchJob(j.id);
            setProgress(s.progress ?? 0);
            setMessage(s.message ?? "");
            setState(s.state ?? null);

            if (s.state === "done") {
              stopPolling();
              const data = await fetchResults(j.id);
              setRows(data);
              setLoading(false);
            }

            if (s.state === "error") {
              stopPolling();
              setLoading(false);
              setRows([]);
              setMessage(s.error ? `Errore: ${s.error}` : "Errore durante l'audit");
            }
          } catch {
            // keep trying
          }
        }, 1000);
      };

      const ev = new EventSource(`${BACKEND_URL}/jobs/${j.id}/events`);
      ev.onmessage = async (e) => {
        let parsed: any = null;
        try {
          parsed = JSON.parse(String(e.data || "{}"));
        } catch {
          parsed = null;
        }

        if (!parsed) return;

        if (parsed.progress !== undefined && parsed.progress !== null) {
          setProgress(parsed.progress ?? 0);
        }
        if (parsed.message !== undefined && parsed.message !== null) {
          setMessage(parsed.message ?? "");
        }
        if (parsed.state !== undefined && parsed.state !== null) {
          setState(parsed.state ?? null);
        }

        if (parsed.state === "done") {
          ev.close();
          stopPolling();
          const data = await fetchResults(j.id);
          setRows(data);
          setLoading(false);
        }

        if (parsed.state === "error") {
          ev.close();
          stopPolling();
          setRows([]);
          setLoading(false);
          setMessage(parsed.error ? `Errore: ${parsed.error}` : "Errore durante l'audit");
        }
      };

      ev.onerror = async () => {
        ev.close();
        // SSE can be flaky on some setups; fall back to polling.
        setMessage("SSE connection dropped. Switching to polling...");
        startPolling();
      };
    } catch {
      setMessage("Failed to start job. Ensure backend is running.");
      setLoading(false);
    }
  }

  function exportCsv() {
    if (!job) return;
    window.open(`${BACKEND_URL}/jobs/${job.id}/export.csv`, "_blank");
  }

  const pitch = React.useMemo(() => {
    if (!pitchRow) return null;
    return buildPitchEmail(pitchRow);
  }, [pitchRow]);

  async function copyPitch() {
    if (!pitch) return;
    const full = `Subject: ${pitch.subject}\n\n${pitch.body}`;
    try {
      await navigator.clipboard.writeText(full);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      // ignore
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <div className="flex items-start justify-between gap-6">
        <div>
          <div className="text-xs text-muted-foreground">Premium Audit</div>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">
            Lead Generation & Audit Machine
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Inserisci categoria e città. Aspetta ~2 minuti. Ottieni un audit con
            opportunità in rosso (sito mancante / pixel mancanti).
          </p>
        </div>

        <div className="pt-1">
          <Button
            variant="secondary"
            onClick={exportCsv}
            disabled={!job || rows.length === 0}
          >
            <FileDown className="mr-2 h-4 w-4" />
            Export to CSV
          </Button>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Input</CardTitle>
            <CardDescription>L'inizio della magia.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="text-xs text-muted-foreground">Categoria Target</div>
              <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
                <select
                  value={categoryPreset}
                  onChange={(e) => {
                    const v = e.target.value;
                    setCategoryMode("preset");
                    setCategoryPreset(v);
                  }}
                  className="h-12 w-full rounded-md border border-input bg-transparent px-4 text-base text-foreground shadow-sm outline-none transition-colors focus-visible:ring-2 focus-visible:ring-muted"
                >
                  {categoryPresets.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>

                <Input
                  value={categoryCustom}
                  onChange={(e) => {
                    setCategoryMode("custom");
                    setCategoryCustom(e.target.value);
                  }}
                  placeholder="Custom category..."
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">City</div>
              <div className="relative">
                <Input
                  placeholder="Scrivi città/paese…"
                  value={demoCity ? demoCity : city}
                  disabled={Boolean(demoCity)}
                  onChange={(e) => {
                    const v = e.target.value;
                    setCityMode("custom");
                    setCityCustom(v);
                    if (!demoCity) setCitySuggestOpen(true);
                  }}
                  onFocus={() => {
                    if (!demoCity) setCitySuggestOpen(true);
                  }}
                  onBlur={() => {
                    window.setTimeout(() => setCitySuggestOpen(false), 150);
                  }}
                />

                {!demoCity && citySuggestOpen && cityFilteredOptions.length > 0 ? (
                  <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-md border border-border bg-background shadow">
                    <div className="max-h-56 overflow-auto">
                      {cityFilteredOptions.map((s) => (
                        <button
                          key={s}
                          type="button"
                          className="block w-full px-3 py-2 text-left text-sm hover:bg-muted/40"
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() => {
                            setCityMode("custom");
                            setCityCustom(s);
                            setCitySuggestOpen(false);
                          }}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : null}
              </div>
            </div>

            <div className="text-xs text-muted-foreground">
              Backend: <span className="text-foreground">FastAPI</span> | Scrape:
              <span className="text-foreground"> Playwright</span> | Audit:
              <span className="text-foreground"> Pixel + SSL + Mobile</span>
            </div>

            <Button
              className="w-full"
              onClick={onStart}
              disabled={loading || category.trim().length < 2 || city.trim().length < 2}
            >
              <Rocket className="mr-2 h-4 w-4" />
              Start Deep Audit
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Live Progress</CardTitle>
            <CardDescription>Feedback in tempo reale mentre lavora.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={progress} />
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{message || "—"}</span>
              <span className="text-muted-foreground">{progress}%</span>
            </div>

            <AnimatePresence mode="wait">
              {loading ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="rounded-lg border border-border bg-muted/30 p-4"
                >
                  <div className="text-sm font-medium">Audit in corso</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {state === "running"
                      ? "Sto analizzando i siti e i pixel..."
                      : "Preparazione job..."}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="idle"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="rounded-lg border border-border bg-muted/10 p-4"
                >
                  <div className="text-sm font-medium">Pronto</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Avvia un audit per vedere lo stream di status.
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <AnimatePresence>
          {loading && rows.length === 0 ? (
            <motion.div
              key="skeleton"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="space-y-3"
            >
              <ResultsSkeleton />
            </motion.div>
          ) : null}

          {!loading && rows.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="rounded-lg border border-border bg-card p-8"
            >
              <div className="text-sm font-medium">No results yet</div>
              <div className="mt-2 text-sm text-muted-foreground">
                Inserisci categoria e città e premi <span className="text-foreground">Start Deep Audit</span>.
              </div>
            </motion.div>
          ) : null}

          {rows.length > 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="space-y-3"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">Risultati</div>
                  <div className="text-xs text-muted-foreground">
                    Evidenzia in rosso opportunità immediate.
                  </div>
                </div>

                <Button
                  variant="secondary"
                  onClick={() => setSortDir((d) => (d === "desc" ? "asc" : "desc"))}
                >
                  {sortDir === "desc" ? (
                    <ArrowDown className="mr-2 h-4 w-4" />
                  ) : (
                    <ArrowUp className="mr-2 h-4 w-4" />
                  )}
                  Sort Opportunities
                </Button>
              </div>

              <ResultsTable
                rows={sortedRows}
                city={city}
                jobId={job?.id || ""}
                onPitch={(row) => {
                  setPitchRow(row);
                  setPitchOpen(true);
                }}
                onPdf={(row) => {
                  downloadPdfReport(row);
                }}
              />
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>

      <Dialog
        open={pitchOpen}
        onOpenChange={(o) => {
          setPitchOpen(o);
          if (!o) {
            setPitchRow(null);
            setCopied(false);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Smart Sales Script</DialogTitle>
            <DialogDescription>
              Email pronta da copiare e inviare, basata sull'audit.
            </DialogDescription>
          </DialogHeader>

          <div className="mt-4 space-y-3">
            <div className="rounded-md border border-border bg-muted/20 p-4">
              <div className="text-xs text-muted-foreground">Subject</div>
              <div className="mt-1 text-sm font-medium">
                {pitch?.subject ?? ""}
              </div>
            </div>

            <div className="rounded-md border border-border bg-muted/20 p-4">
              <div className="text-xs text-muted-foreground">Body</div>
              <pre className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-foreground">
                {pitch?.body ?? ""}
              </pre>
            </div>
          </div>

          <DialogFooter>
            <Button variant="secondary" onClick={copyPitch}>
              <Copy className="mr-2 h-4 w-4" />
              {copied ? "Copied" : "Copy to Clipboard"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
