@echo off
setlocal enableextensions enabledelayedexpansion

if defined LG_DEBUG echo on

set "ROOT=%~dp0"
set "LOG=%ROOT%start_software.log"
echo [%date% %time%] START_SOFTWARE.bat avviato - ROOT=%ROOT%>>"%LOG%"

REM Keep running in this console. The script ends with PAUSE, so the window will not close.
set "__LG_PERSIST=1"

REM -------------------------
REM Preflight checks
REM -------------------------
set "NODE_EXE=node"
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
"%NODE_EXE%" -v >nul 2>&1
if errorlevel 1 (
  echo.
  echo ================================================
  echo ERRORE: Node.js non trovato.
  echo Installa Node.js 18+ e riprova.
  echo https://nodejs.org/
  echo ================================================
  echo.
  pause
  exit /b 1
)

set "NPM_CMD=npm"
if exist "%ProgramFiles%\nodejs\npm.cmd" set "NPM_CMD=%ProgramFiles%\nodejs\npm.cmd"
if exist "%ProgramFiles(x86)%\nodejs\npm.cmd" set "NPM_CMD=%ProgramFiles(x86)%\nodejs\npm.cmd"
call "%NPM_CMD%" -v >nul 2>&1
if errorlevel 1 (
  echo.
  echo ================================================
  echo ERRORE: npm non trovato.
  echo Reinstalla Node.js 18+ (include npm) e riprova.
  echo https://nodejs.org/
  echo ================================================
  echo.
  pause
  exit /b 1
)

where py >nul
if errorlevel 1 (
  where python >nul
  if errorlevel 1 (
    echo.
    echo ================================================
    echo ERRORE: Python non trovato.
    echo Installa Python 3.11+ e riprova.
    echo https://www.python.org/downloads/
    echo ================================================
    echo.
    pause
    exit /b 1
  )
)

echo ==================================================
echo Lead Generation ^& Audit Machine - Avvio
echo ==================================================
echo.
echo [%date% %time%] Preflight OK>>"%LOG%"

REM -------------------------
REM Python venv + dependencies
REM -------------------------
set "VENV_DIR=%ROOT%.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"

if not exist "%VENV_PY%" (
  echo [1/4] Creo ambiente virtuale Python...
  echo [%date% %time%] Creo venv: py -3 -m venv "%VENV_DIR%">>"%LOG%"
  py -3 -m venv "%VENV_DIR%"
  if errorlevel 1 (
    echo Errore: impossibile creare la venv con 'py -3'. Provo con 'python'...
    echo [%date% %time%] Venv con py -3 fallita (errorlevel=%errorlevel%)>>"%LOG%"
    python -m venv "%VENV_DIR%" || goto :FAIL
  )
)

echo [%date% %time%] Venv OK: %VENV_PY%>>"%LOG%"

echo [2/4] Installo/aggiorno dipendenze backend (pip)...
echo [%date% %time%] pip upgrade...>>"%LOG%"
"%VENV_PY%" -m pip install --upgrade pip setuptools wheel || goto :FAIL
echo [%date% %time%] pip install requirements...>>"%LOG%"
"%VENV_PY%" -m pip install -r "%ROOT%backend\requirements.txt" || goto :FAIL

echo [%date% %time%] Backend deps OK>>"%LOG%"

echo [3/4] Verifico Playwright (browser)...
echo [%date% %time%] playwright install chromium...>>"%LOG%"
"%VENV_PY%" -m playwright install chromium || goto :FAIL

echo [%date% %time%] Playwright OK>>"%LOG%"

REM -------------------------
REM Frontend dependencies
REM -------------------------
echo [4/4] Installo/aggiorno dipendenze frontend (npm)...
pushd "%ROOT%frontend" || goto :FAIL
set "NEED_NPM=0"
if not exist "node_modules" set "NEED_NPM=1"
if not exist "node_modules\.bin\next.cmd" set "NEED_NPM=1"
if "%NEED_NPM%"=="1" (
  echo [%date% %time%] npm install need=%NEED_NPM%>>"%LOG%"
  if exist "package-lock.json" (
    call "%NPM_CMD%" ci
    if errorlevel 1 goto :NPM_CI_FALLBACK
  ) else (
    call "%NPM_CMD%" install || goto :FAIL
  )
) else (
  echo [4/4] Dipendenze frontend gia' presenti e Next trovato.
  echo [%date% %time%] Frontend deps OK (Next trovato)>>"%LOG%"
)
popd

goto :AFTER_NPM

:NPM_CI_FALLBACK
echo npm ci fallito, provo con npm install...
echo [%date% %time%] npm ci fallito, fallback a npm install>>"%LOG%"
call "%NPM_CMD%" install || goto :FAIL

:AFTER_NPM

echo [%date% %time%] Avvio processi backend/frontend...>>"%LOG%"

echo.
echo Avvio backend (minimizzato) + frontend...
echo.

REM -------------------------
REM Start backend minimized
REM -------------------------
start "Backend - FastAPI" /D "%ROOT%" cmd /k ""%VENV_PY%" -m uvicorn backend.main:app --port 8000"

REM -------------------------
REM Start frontend
REM -------------------------
start "Frontend - Next.js" /D "%ROOT%frontend" cmd /k ""%NPM_CMD%" run dev"

REM -------------------------
REM Open browser (give dev server a moment)
REM -------------------------
echo Attendo che il frontend sia pronto su http://localhost:3000 ...
timeout /t 3 /nobreak >nul
start "" "http://localhost:3000"

echo.
echo ================================================
echo SOFTWARE COMPLETO avviato.
echo Browser: http://localhost:3000
echo Nota: backend/frontend restano attivi nelle loro finestre.
echo Premi un tasto per chiudere SOLO questa finestra.
echo ================================================
echo.
echo [%date% %time%] Browser aperto: http://localhost:3000>>"%LOG%"
pause
exit /b 0

:FAIL
echo.
echo ================================================
echo ERRORE durante la preparazione o l'avvio.
echo - Assicurati di avere installato Node.js 18+ e Python 3.11+
echo - Poi riprova.
echo ================================================
echo.
echo [%date% %time%] FAIL (errorlevel=%errorlevel%)>>"%LOG%"
pause
exit /b 1
