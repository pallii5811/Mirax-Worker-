import asyncio
import csv
import io
import json
import os
import re
import time
import uuid
import traceback
from urllib.parse import quote
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Literal, Optional, Tuple

# Windows: Playwright spawns browser subprocesses. SelectorEventLoop on Windows
# does NOT support subprocess; ensure Proactor is used.
if os.name == "nt":
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except Exception:
        pass

import httpx
from bs4 import BeautifulSoup
from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

try:
    from playwright.async_api import async_playwright
except Exception:  # pragma: no cover
    async_playwright = None

try:
    from playwright.sync_api import sync_playwright
except Exception:  # pragma: no cover
    sync_playwright = None


class StartJobRequest(BaseModel):
    category: str = Field(min_length=2, max_length=120)
    city: str = Field(min_length=2, max_length=120)


class AuditSignals(BaseModel):
    has_facebook_pixel: bool = False
    has_tiktok_pixel: bool = False
    has_gtm: bool = False
    has_ssl: bool = False
    is_mobile_responsive: bool = False


class BusinessResult(BaseModel):
    business_name: str
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    website_status: Literal["HAS_WEBSITE", "MISSING_WEBSITE"]
    audit: AuditSignals


class JobStatus(BaseModel):
    id: str
    state: Literal["queued", "running", "done", "error"]
    progress: int
    message: str
    started_at: float
    finished_at: Optional[float] = None
    error: Optional[str] = None


@dataclass
class Job:
    id: str
    category: str
    city: str
    state: str = "queued"
    progress: int = 0
    message: str = "Queued"
    started_at: float = field(default_factory=lambda: time.time())
    finished_at: Optional[float] = None
    error: Optional[str] = None
    results: List[BusinessResult] = field(default_factory=list)
    events: asyncio.Queue = field(default_factory=asyncio.Queue)

    async def emit(self, progress: int, message: str) -> None:
        self.progress = max(0, min(100, progress))
        self.message = message
        await self.events.put(
            {
                "progress": self.progress,
                "message": message,
                "state": self.state,
                "error": self.error,
            }
        )


JOBS: Dict[str, Job] = {}

app = FastAPI(title="Lead Gen & Audit Backend", version="0.1.0")

_allow_all = os.getenv("CORS_ALLOW_ALL", "1") == "1"

_demo_city = (os.getenv("DEMO_CITY") or "").strip()
_demo_categories_raw = (os.getenv("DEMO_CATEGORIES") or "").strip()
_demo_categories = [c.strip() for c in _demo_categories_raw.split(",") if c.strip()]
try:
    _demo_max_results = int((os.getenv("DEMO_MAX_RESULTS") or "0").strip() or "0")
except Exception:
    _demo_max_results = 0

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if _allow_all else ["http://localhost:3000"],
    # IMPORTANT: browsers disallow '*' with credentials. For local standalone we don't need cookies.
    allow_credentials=False if _allow_all else True,
    allow_methods=["*"] ,
    allow_headers=["*"],
)


PIXEL_PATTERNS = {
    "facebook": re.compile(r"fbevents\\.js", re.IGNORECASE),
    "tiktok": re.compile(r"tiktok\\.com/i18n/pixel", re.IGNORECASE),
    "gtm": re.compile(r"googletagmanager\\.com", re.IGNORECASE),
}


async def fetch_html(url: str) -> str:
    raise RuntimeError("fetch_html signature changed; use fetch_html_with_final_url")


async def fetch_html_with_final_url(url: str) -> Tuple[str, str]:
    timeout = httpx.Timeout(18.0, connect=8.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        r = await client.get(url, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        return r.text, str(r.url)


def normalize_website(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    u = url.strip()
    if not u:
        return None
    if not u.startswith("http://") and not u.startswith("https://"):
        u = "https://" + u
    return u


def audit_from_html(html: str) -> AuditSignals:
    s = AuditSignals()
    if PIXEL_PATTERNS["facebook"].search(html):
        s.has_facebook_pixel = True
    if PIXEL_PATTERNS["tiktok"].search(html):
        s.has_tiktok_pixel = True
    if PIXEL_PATTERNS["gtm"].search(html):
        s.has_gtm = True

    soup = BeautifulSoup(html, "html.parser")
    viewport = soup.find("meta", attrs={"name": re.compile(r"viewport", re.IGNORECASE)})
    s.is_mobile_responsive = viewport is not None
    return s


def extract_email_from_html(html: str) -> Optional[str]:
    try:
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.select('a[href^="mailto:"]'):
            href = a.get("href") or ""
            if not href.lower().startswith("mailto:"):
                continue
            value = href.split(":", 1)[1].strip()
            value = value.split("?", 1)[0].strip()
            value = value.strip("<>\"' ")
            if not value:
                continue
            if re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", value):
                return value
        return None
    except Exception:
        return None


async def audit_website(website: str) -> Tuple[AuditSignals, Optional[str]]:
    website = normalize_website(website) or website
    signals = AuditSignals()
    for attempt in range(2):
        try:
            html, final_url = await fetch_html_with_final_url(website)
            parsed = audit_from_html(html)
            parsed.has_ssl = final_url.lower().startswith("https://")
            email = extract_email_from_html(html)
            return parsed, email
        except Exception:
            if attempt == 0:
                await asyncio.sleep(0.6)
                continue
            return signals, None


async def scrape_google_maps_playwright(category: str, city: str) -> List[Dict[str, Any]]:
    # NOTE: On Windows + Python 3.13, Playwright async API may fail with
    # NotImplementedError due to asyncio subprocess limitations.
    # Using sync_playwright inside a thread avoids asyncio subprocess entirely.
    if sync_playwright is None:
        raise RuntimeError("Playwright not installed")

    return await asyncio.to_thread(_scrape_google_maps_sync, category, city)


def _scrape_google_maps_sync(category: str, city: str) -> List[Dict[str, Any]]:
    base_query = f"{category} {city}"
    query_variants = [base_query, f"{category} {city}, Italia"]
    last_error: Optional[str] = None
    started = time.time()

    with sync_playwright() as p:
        for attempt, q in enumerate(query_variants, start=1):
            results: List[Dict[str, Any]] = []
            try:
                browser = p.chromium.launch(
                    headless=False,
                    args=[
                        "--lang=it-IT",
                        "--disable-blink-features=AutomationControlled",
                        "--no-default-browser-check",
                    ],
                )
                context = browser.new_context(
                    locale="it-IT",
                    timezone_id="Europe/Rome",
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    viewport={"width": 1400, "height": 900},
                )
                page = context.new_page()
                page.set_default_timeout(20000)
                try:
                    page.set_extra_http_headers({"Accept-Language": "it-IT,it;q=0.9,en;q=0.8"})
                except Exception:
                    pass

                def try_handle_consent() -> None:
                    texts = [
                        "Accetta tutto",
                        "Rifiuta tutto",
                        "I agree",
                        "Accept all",
                        "Reject all",
                    ]

                    def click_in_frame(frame) -> bool:
                        # Try common Google consent button id as well
                        try:
                            btn_css = frame.locator('#L2AGLb')
                            if btn_css.count() and btn_css.is_visible():
                                btn_css.click(timeout=2000)
                                page.wait_for_timeout(600)
                                return True
                        except Exception:
                            pass
                        for t in texts:
                            try:
                                btn = frame.get_by_role("button", name=t).first
                                if btn.count() and btn.is_visible():
                                    btn.click(timeout=2500)
                                    page.wait_for_timeout(700)
                                    return True
                            except Exception:
                                continue
                        return False

                    try:
                        if click_in_frame(page):
                            return
                    except Exception:
                        pass

                    for fr in page.frames:
                        try:
                            if fr == page.main_frame:
                                continue
                            if click_in_frame(fr):
                                return
                        except Exception:
                            continue

                search_url = f"https://www.google.com/maps/search/{quote(q)}?hl=it&gl=it&entry=ttu"
                page.goto(search_url, wait_until="domcontentloaded", timeout=55000)
                page.wait_for_timeout(1400)
                try_handle_consent()

                # Guard rail: if we're close to the global 240s timeout, bail out early.
                if time.time() - started > 210:
                    context.close()
                    browser.close()
                    return results

                # Wait for either results or any blocking state
                cards = page.locator('div[role="article"]')
                alt_cards = page.locator('div.Nv2PK')
                for _ in range(18):
                    try_handle_consent()
                    if cards.count() > 0 or alt_cards.count() > 0:
                        break
                    # Sometimes feed appears later; give it a bit more time overall (~10s)
                    page.wait_for_timeout(800)

                # Prefer role=article, otherwise fallback to Nv2PK
                if cards.count() == 0 and alt_cards.count() > 0:
                    cards = alt_cards

                if cards.count() == 0:
                    html = page.content().lower()
                    if "unusual traffic" in html or "captcha" in html:
                        last_error = (
                            "Google blocked the request (captcha/unusual traffic). Try again later or from another network."
                        )
                    else:
                        last_error = (
                            "Google Maps returned 0 results. Trying a slightly different query or city may help."
                        )
                    context.close()
                    browser.close()
                    # Retry with next variant if available
                    if attempt < len(query_variants):
                        time.sleep(1.0)
                        continue
                    raise RuntimeError(last_error)

                # Scroll feed to load more results
                feed = page.locator('div[role="feed"]').first
                for _ in range(6):
                    try:
                        feed.evaluate("(el) => { el.scrollBy(0, 1400); }")
                    except Exception:
                        try:
                            page.mouse.wheel(0, 1200)
                        except Exception:
                            pass
                    page.wait_for_timeout(350)

                # Recompute cards with the same fallback logic (Maps sometimes uses Nv2PK blocks)
                cards = page.locator('div[role="article"]')
                alt_cards = page.locator('div.Nv2PK')
                if cards.count() == 0 and alt_cards.count() > 0:
                    cards = alt_cards
                count = cards.count()

                # Cap processed results to avoid long sessions / UI changes causing timeouts.
                cap = 15
                if _demo_city and _demo_max_results > 0:
                    cap = _demo_max_results
                max_cards = min(count, cap)

                for idx in range(max_cards):
                    if time.time() - started > 225:
                        break
                    card = cards.nth(idx)
                    try:
                        name = (
                            card.locator(".fontHeadlineSmall").first.text_content(timeout=1500) or ""
                        ).strip()
                    except Exception:
                        name = ""
                    if not name:
                        continue

                    try:
                        card.click()
                        page.wait_for_timeout(650)
                    except Exception:
                        pass

                    address = None
                    phone = None
                    website = None

                    try:
                        address = page.locator('button[data-item-id="address"]').first.text_content(timeout=1500)
                    except Exception:
                        address = None

                    try:
                        phone = page.locator('button[data-item-id^="phone"]').first.text_content(timeout=1500)
                    except Exception:
                        phone = None

                    try:
                        website = page.locator('a[data-item-id="authority"]').first.get_attribute(
                            "href", timeout=1500
                        )
                    except Exception:
                        website = None

                    results.append(
                        {
                            "business_name": name,
                            "address": address.strip() if address else None,
                            "phone": phone.strip() if phone else None,
                            "website": website,
                        }
                    )

                context.close()
                browser.close()

                return results
            except Exception as e:
                try:
                    context.close()
                except Exception:
                    pass
                try:
                    browser.close()
                except Exception:
                    pass
                last_error = str(e) or last_error
                # Small backoff then next variant
                if attempt < len(query_variants):
                    time.sleep(1.0)
                    continue
                raise


async def run_job(job: Job) -> None:
    job.state = "running"
    await job.emit(3, "Scraping Maps...")

    try:
        raw = await scrape_google_maps_playwright(job.category, job.city)

        if not raw:
            raise RuntimeError("No results returned from Google Maps. Try a different query or city.")

        await job.emit(12, f"Trovate {len(raw)} attività. Avvio audit...")

        results: List[BusinessResult] = []
        total = max(1, len(raw))

        for i, item in enumerate(raw):
            name = item.get("business_name") or "Unknown"
            website = item.get("website")
            website_norm = normalize_website(website) if website else None

            if website_norm:
                await job.emit(
                    12 + int((i / total) * 80),
                    f"Analizzando sito web di {name}...",
                )
                try:
                    audit, email = await asyncio.wait_for(
                        audit_website(website_norm),
                        timeout=25.0,
                    )
                except asyncio.TimeoutError:
                    audit, email = AuditSignals(), None
                website_status: Literal["HAS_WEBSITE", "MISSING_WEBSITE"] = "HAS_WEBSITE"
            else:
                audit = AuditSignals()
                email = None
                website_status = "MISSING_WEBSITE"

            results.append(
                BusinessResult(
                    business_name=name,
                    address=item.get("address"),
                    phone=item.get("phone"),
                    email=email,
                    website=website_norm,
                    website_status=website_status,
                    audit=audit,
                )
            )

        job.results = results
        job.state = "done"
        job.finished_at = time.time()
        await job.emit(100, "Audit completato. Risultati pronti.")
    except Exception as e:
        job.state = "error"
        job.finished_at = time.time()
        job.error = str(e)
        print("JOB ERROR:", job.error)
        print(traceback.format_exc())
        await job.emit(100, f"Errore: {job.error}")


@app.get("/health")
async def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/jobs", response_model=JobStatus)
async def start_job(payload: StartJobRequest, background: BackgroundTasks) -> JobStatus:
    if _demo_city:
        if payload.city.strip() != _demo_city:
            raise HTTPException(status_code=400, detail=f"DEMO: città consentita: {_demo_city}")
    if _demo_categories:
        if payload.category.strip() not in _demo_categories:
            raise HTTPException(
                status_code=400,
                detail=f"DEMO: categorie consentite: {', '.join(_demo_categories)}",
            )

    job_id = str(uuid.uuid4())
    job = Job(id=job_id, category=payload.category, city=payload.city)
    JOBS[job_id] = job
    background.add_task(run_job, job)

    return JobStatus(
        id=job.id,
        state=job.state,
        progress=job.progress,
        message=job.message,
        started_at=job.started_at,
        finished_at=job.finished_at,
        error=job.error,
    )


@app.get("/jobs/{job_id}", response_model=JobStatus)
async def get_job(job_id: str) -> JobStatus:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    return JobStatus(
        id=job.id,
        state=job.state,
        progress=job.progress,
        message=job.message,
        started_at=job.started_at,
        finished_at=job.finished_at,
        error=job.error,
    )


@app.get("/jobs/{job_id}/results", response_model=List[BusinessResult])
async def get_results(job_id: str) -> List[BusinessResult]:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job.results


@app.get("/jobs/{job_id}/events")
async def job_events(job_id: str) -> StreamingResponse:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    async def gen() -> AsyncGenerator[bytes, None]:
        yield b"retry: 1000\n\n"
        # Send an initial snapshot immediately.
        init_payload = json.dumps(
            {
                "progress": job.progress,
                "message": job.message,
                "state": job.state,
                "error": job.error,
            },
            ensure_ascii=False,
        )
        yield f"data: {init_payload}\n\n".encode("utf-8")
        while True:
            try:
                event = await asyncio.wait_for(job.events.get(), timeout=10.0)
            except asyncio.TimeoutError:
                # Keep-alive comment line (SSE clients ignore it)
                yield b": keep-alive\n\n"
                continue
            payload = json.dumps(event, ensure_ascii=False)
            data = f"data: {payload}\n\n"
            yield data.encode("utf-8")
            if job.state in {"done", "error"} and job.progress >= 100:
                break

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/jobs/{job_id}/export.csv")
async def export_csv(job_id: str) -> Response:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(
        [
            "Business Name",
            "Address",
            "Phone",
            "Website",
            "Website Status",
            "Has SSL",
            "Mobile Responsive",
            "Facebook Pixel",
            "TikTok Pixel",
            "GTM",
        ]
    )

    for r in job.results:
        writer.writerow(
            [
                r.business_name,
                r.address or "",
                r.phone or "",
                r.website or "",
                r.website_status,
                "YES" if r.audit.has_ssl else "NO",
                "YES" if r.audit.is_mobile_responsive else "NO",
                "YES" if r.audit.has_facebook_pixel else "NO",
                "YES" if r.audit.has_tiktok_pixel else "NO",
                "YES" if r.audit.has_gtm else "NO",
            ]
        )

    data = output.getvalue().encode("utf-8")
    filename = f"audit_{job.category}_{job.city}.csv".replace(" ", "_")

    return Response(
        content=data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
